-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Agu 2019 pada 18.10
-- Versi server: 10.1.31-MariaDB
-- Versi PHP: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_makanan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pesanan_makanan`
--

CREATE TABLE `detail_pesanan_makanan` (
  `id` int(11) NOT NULL,
  `id_makanan` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `nomor_pesanan` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pesanan_minuman`
--

CREATE TABLE `detail_pesanan_minuman` (
  `id` int(11) NOT NULL,
  `id_minuman` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `nomor_pesanan` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `makanan`
--

CREATE TABLE `makanan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` varchar(25) NOT NULL,
  `status` enum('READY','NO READY') NOT NULL DEFAULT 'READY'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `makanan`
--

INSERT INTO `makanan` (`id`, `nama`, `harga`, `status`) VALUES
(2, 'Bubur sum sum', '10000', 'READY'),
(3, 'bubur ayam', '20000', 'READY');

-- --------------------------------------------------------

--
-- Struktur dari tabel `meja`
--

CREATE TABLE `meja` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `meja`
--

INSERT INTO `meja` (`id`, `nama`) VALUES
(1, 'meja-1'),
(3, 'meja-2'),
(4, 'meja-3'),
(5, 'meja-4'),
(6, 'meja-5'),
(7, 'meja-6');

-- --------------------------------------------------------

--
-- Struktur dari tabel `minuman`
--

CREATE TABLE `minuman` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` varchar(25) DEFAULT NULL,
  `status` enum('READY','NO READY') NOT NULL DEFAULT 'READY'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `minuman`
--

INSERT INTO `minuman` (`id`, `nama`, `harga`, `status`) VALUES
(1, 'ice tea', '15000', 'READY'),
(2, 'juice lemon', '10000', 'NO READY');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `nomor_pesanan` varchar(100) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `meja` varchar(25) DEFAULT NULL,
  `id_pelayanan` int(11) DEFAULT NULL,
  `status` enum('AKTIF','TIDAK AKTIF') NOT NULL DEFAULT 'AKTIF'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`nomor_pesanan`, `nama`, `meja`, `id_pelayanan`, `status`) VALUES
('ERP08292019-003', 'rudi', '3', 1, 'AKTIF'),
('ERP08292019-004', 'sita', '1', 2, 'AKTIF');

-- --------------------------------------------------------

--
-- Struktur dari tabel `record`
--

CREATE TABLE `record` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `record`
--

INSERT INTO `record` (`id`, `id_user`, `keterangan`) VALUES
(1, 2, 'menambahkan pesanan ERP08292019-003'),
(2, 1, 'menambahkan pesanan ERP08292019-003'),
(5, 2, 'menambahkan pesanan ERP08292019-003'),
(6, 2, 'menambahkan pesanan ERP08292019-003'),
(7, 2, 'menambahkan pesanan ERP08292019-003'),
(8, 2, 'menambahkan pesanan ERP08292019-003'),
(9, 2, 'menambahkan pesanan ERP08292019-004');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` enum('pelayan','kasir') NOT NULL DEFAULT 'pelayan'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`) VALUES
(1, 'rudi', 'rudi', 'rudi', 'pelayan'),
(2, 'redi', 'redi', 'redi', 'kasir');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `detail_pesanan_makanan`
--
ALTER TABLE `detail_pesanan_makanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `detail_pesanan_minuman`
--
ALTER TABLE `detail_pesanan_minuman`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `makanan`
--
ALTER TABLE `makanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `meja`
--
ALTER TABLE `meja`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `minuman`
--
ALTER TABLE `minuman`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`nomor_pesanan`);

--
-- Indeks untuk tabel `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail_pesanan_makanan`
--
ALTER TABLE `detail_pesanan_makanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `detail_pesanan_minuman`
--
ALTER TABLE `detail_pesanan_minuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `makanan`
--
ALTER TABLE `makanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `meja`
--
ALTER TABLE `meja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `minuman`
--
ALTER TABLE `minuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `record`
--
ALTER TABLE `record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
