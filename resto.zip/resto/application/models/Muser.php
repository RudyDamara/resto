<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Muser extends CI_Model
{

    public $table = 'user';
    public $id = 'id';
    public $order = 'ASC';

    function __construct()
    {
        parent::__construct();
    }
    function data($number,$offset){
		return $query = $this->db->get('user',$number,$offset)->result();		
	}
    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }
    public function jumlah_data(){
		return $this->db->get('user')->num_rows();
    }
    
    //get data by id
     function get_result_by_id_kategori($id)
     {
         $this->db->where("id_kategori", $id);
         return $this->db->get($this->table)->result();
     }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

    // get data login
    function login($username,$password)
    {
        // $this->db->where('username', $username);
        $this->db->where('password', $password);
        return $this->db->get('user')->row();
    }

}
