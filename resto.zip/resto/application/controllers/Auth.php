<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {


   public function __construct(){
     parent::__construct();
     $this->load->model('Mpelanggan');
     $this->load->model('Muser');
   }

   	public function index()
   	{
			$this->load->view('template/header');
			$this->load->view('daftarmenu/Vlogin');
			$this->load->view('template/footer');
   	}

    public function login()
   	{
   		$this->load->view('template/header');
   		$this->load->view('daftarmenu/Vlogin');
   		$this->load->view('template/footer');
		}
		 
		public function login_user()
   	{
   		$username = $this->input->post('username');
     	$password = $this->input->post('password');
			// echo $username;
			// echo $password;
			// die();
      //mengambil data login
			$get_login = $this->Muser->login("$username","$password");
			// $get_login = $this->Muser->login('rudi','rudi');
			// var_dump($get_login);
      if ($get_login->id != null) {

        //data session
        $data_login = array(
          'id' => $get_login->id,
          'username' => $get_login->username,
          'nama' => $get_login->nama,
          'level' => $get_login->level,
          // 'status_login' => "oke",
				);
				$login_sukses = $this->session->set_userdata($data_login);
				// $json_login =	json_encode($login_sukses);
				// echo $json_login;
				// echo json_encode();
				echo json_encode(array(
					'status'=>'sukses',
					'id' => $get_login->id,
          'username' => $get_login->username,
          'nama' => $get_login->nama,
          'level' => $get_login->level
				));
				
      } else {
        echo json_encode(array(
					'status'=>'nosukses'
				));
      }

		 }
		 

    public function authentic_log_in()
   	{
   		$username = $this->input->get('u');
     	$password = $this->input->get('p');
			// echo $username;
			// echo $password;
			// die();
      //mengambil data login
			$get_login = $this->Muser->login("$username","$password");
			// $get_login = $this->Muser->login('rudi','rudi');
			// var_dump($get_login);
      if ($get_login->id != null) {

        //data session
        $data_login = array(
          'id' => $get_login->id,
          'username' => $get_login->username,
          'nama' => $get_login->nama,
          'level' => $get_login->level,
          // 'status_login' => "oke",
				);
				$login_sukses = $this->session->set_userdata($data_login);
				// $json_login =	json_encode($login_sukses);
				// echo $json_login;
				// echo json_encode();
				echo json_encode(array(
					'status'=>'sukses',
					'id' => $get_login->id,
          'username' => $get_login->username,
          'nama' => $get_login->nama,
          'level' => $get_login->level
				));
				
      } else {
        echo json_encode(array(
					'status'=>'nosukses'
				));
      }

		 }

    public function log_out()
   	{
        //menghilangkan session
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('id_pelanggan');
        $this->session->unset_userdata('status_login');
        redirect(base_url('auth/login'));
   	}
}
