<?php

date_default_timezone_set('Asia/Jakarta');

defined('BASEPATH') OR exit('No direct script access allowed');

class Record extends CI_Controller {

   public function __construct(){
     parent::__construct();
     $this->load->model('Mrecord');
     if ($this->session->userdata('level')!='pelayan') {
      redirect(base_url("auth"));
     }
     
   }

  public function index()
  {
    //
    $data['record'] = $this->Mrecord->get_all_by_id($this->session->userdata('id'));
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vrecord', $data);
    $this->load->view('template/footer');
  }

  public function print()
  {
    //
    $data['record'] = $this->Mrecord->get_all_by_id($this->session->userdata('id'));
    $this->load->view('daftarmenu/Vprintrecord', $data);
  }

}
