<?php

date_default_timezone_set('Asia/Jakarta');

defined('BASEPATH') OR exit('No direct script access allowed');

class Pesanan extends CI_Controller {

   public function __construct(){
     parent::__construct();
     $this->load->model('MPesanan');
     $this->load->model('Mmeja');
     $this->load->model('Mmakanan');
     $this->load->model('Mminuman');
     $this->load->model('Mrecord');
     if ($this->session->userdata('level')!='pelayan') {
      redirect(base_url("auth"));
     }
     
   }

  public function index()
  {
    //
    $data['pesanan'] = $this->MPesanan->get_join_all();
    $data['meja'] = $this->Mmeja->get_all();
    $data['makanan'] = $this->Mmakanan->get_all_ready();
    $data['minuman'] = $this->Mminuman->get_all_ready();
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vpesanan', $data);
    $this->load->view('template/footer');
  }

  public function data()
  {
    $data['pesanan'] = $this->MPesanan->get_all();
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vpesanan', $data);
    $this->load->view('template/footer');
  }

  public function update($id_prov)
  {
    $data['update']='update';
    $data['pesanan'] = $this->MPesanan->get_all();
    $data['meja'] = $this->Mmeja->get_all();
    $data['data_update'] = $this->MPesanan->get_by_id($id_prov);
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vpesanan', $data);
    $this->load->view('template/footer');
  }


	public function insert_action()
	{
    $get_last = $this->MPesanan->get_maxlast();
    $no_urut = (int) substr($get_last->nomorpesanan,12,3);
    $tambah_no_urut = $no_urut+1;
    $nomor_pesanan = "ERP".date("mdY")."-".sprintf("%03s",$tambah_no_urut);
    
		$data = array(
			'nomor_pesanan' => $nomor_pesanan,
      'nama' => $this->input->post('atasnama'),
      'meja' => $this->input->post('meja'),
      'id_pelayanan' => $this->session->userdata('id')
		);

    $this->MPesanan->insert($data);

    $data_record = array(
      'keterangan' => "menambahkan pesanan ".$nomor_pesanan,
      'id_user' => $this->session->userdata('id')
		);
    $this->Mrecord->insert($data_record);

		redirect(base_url("pelayan/Pesanan/detail_pesanan/".$nomor_pesanan));
  }
  
  public function detail_pesanan($nomor_pesanan)
	{
		$data = array(
			'nomor_pesanan' => $nomor_pesanan,
		);

    $data['makanan'] = $this->Mmakanan->get_all_ready();
    $data['minuman'] = $this->Mminuman->get_all_ready();

    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vdetailpesanan', $data);
    $this->load->view('template/footer');
	}

	public function update_action()
  {
		//data yang akan di ubah dimasukkan ke array
    $data = array(
      'nama' => $this->input->post('atasnama'),
      'meja' => $this->input->post('meja'),
      'id_pelayanan' => $this->session->userdata('id_pelayanan')
		);

    $data_record = array(
      'keterangan' => "mengupdate pesanan ".$this->input->post('nomor_pemesanan'),
      'id_user' => $this->session->userdata('id')
		);
    $this->Mrecord->insert($data_record);
    
		// mengirimkan data primary key dan data yang akan di ubah
		$this->MPesanan->update($this->input->post('nomor_pemesanan'), $data);
    redirect(base_url("pelayan/Pesanan"));
  }

  public function hapus(){
    $id = $this->input->post("id");
    $hapus_data = $this->MPesanan->delete($id);
    // echo "data terhapus";
    redirect(base_url("pelayan/Pesanan"));
  }

}
