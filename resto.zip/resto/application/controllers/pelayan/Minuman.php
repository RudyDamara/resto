<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Minuman extends CI_Controller {

   public function __construct(){
     parent::__construct();
     $this->load->model('Mminuman');
     if ($this->session->userdata('level')!='pelayan') {
      redirect(base_url("auth"));
     }
   }

	public function index()
	{
    $data['minuman'] = $this->Mminuman->get_all();
		$this->load->view('template/header');
		$this->load->view('daftarmenu/Vminuman', $data);
		$this->load->view('template/footer');
	}

  public function data()
  {
    $data['minuman'] = $this->Mminuman->get_all();
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vminuman', $data);
    $this->load->view('template/footer');
  }

  public function update($id_prov)
  {
    $data['update']='update';
    $data['minuman'] = $this->Mminuman->get_all();
    $data['data_update'] = $this->Mminuman->get_by_id($id_prov);
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vminuman', $data);
    $this->load->view('template/footer');
  }

	public function insert_action()
	{
		//data yang akan di ubah dimasukkan ke array
		$data = array(
			'id' => $this->input->post('id'),
			'nama' => $this->input->post('nama'),
			'harga ' => $this->input->post('harga')
		);

		// mengirimkan data primary key dan data yang akan di ubah
		$this->Mminuman->insert($data);

		redirect(base_url("Minuman"));
	}

	public function update_action()
  {
		//data yang akan di ubah dimasukkan ke array
    $data = array(
			'nama' => $this->input->post('nama'),
      'harga' => $this->input->post('harga'),
      'status' => $this->input->post('status') );

		// mengirimkan data primary key dan data yang akan di ubah
		$this->Mminuman->update($this->input->post('id'), $data);

    redirect(base_url("Minuman"));
  }

  public function hapus(){
    $id = $this->input->post("id");
    $hapus_data = $this->Mminuman->delete($id);
    // echo "data terhapus";
    redirect(base_url("Minuman"));
  }
}
