<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Makanan extends CI_Controller {

   public function __construct(){
     parent::__construct();
     $this->load->model('Mmakanan');
     if ($this->session->userdata('level')!='pelayan') {
      redirect(base_url("auth"));
     }
   }

	public function index()
	{
    $data['makanan'] = $this->Mmakanan->get_all();
		$this->load->view('template/header');
		$this->load->view('daftarmenu/Vmakanan', $data);
		$this->load->view('template/footer');
	}

  public function data()
  {
    $data['provinsi'] = $this->Mmakanan->get_all();
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vmakanan', $data);
    $this->load->view('template/footer');
  }

  public function update($idmakanan)
  {
    $data['update']='update';
    $data['makanan'] = $this->Mmakanan->get_all();
    $data['data_update'] = $this->Mmakanan->get_by_id($idmakanan);
    $this->load->view('template/header');
    $this->load->view('daftarmenu/Vmakanan', $data);
    $this->load->view('template/footer');
  }

	public function insert_action()
	{
		//data yang akan di ubah dimasukkan ke array
		$data = array(
			'id' => $this->input->post('id'),
			'nama' => $this->input->post('nama'),
			'harga ' => $this->input->post('harga')
		);

		// mengirimkan data primary key dan data yang akan di ubah
		$this->Mmakanan->insert($data);

		redirect(base_url("Makanan"));
	}

	public function update_action()
  {
		//data yang akan di ubah dimasukkan ke array
    $data = array(
			'nama' => $this->input->post('nama'),
			'harga' => $this->input->post('harga'),
      'status' => $this->input->post('status') );

		// mengirimkan data primary key dan data yang akan di ubah
		$this->Mmakanan->update($this->input->post('id'), $data);

    redirect(base_url("Makanan"));
  }

  public function hapus(){
    $id = $this->input->post("id");
    $hapus_data = $this->Mmakanan->delete($id);
    // echo "data terhapus";
    redirect(base_url("Makanan"));
  }
}
