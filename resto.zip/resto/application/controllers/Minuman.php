<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Minuman extends CI_Controller {

   public function __construct(){
     parent::__construct();
     $this->load->model('Mminuman');

   }

   public function get_all_data()
   {
     $data = $this->Mminuman->get_all();
     echo json_encode($data);
   }
 
   public function get_by_type()
   {
     $type=$this->input->get('p');
     $data = $this->Mminuman->get_by_id($type);
     echo json_encode($data);
   }
}
