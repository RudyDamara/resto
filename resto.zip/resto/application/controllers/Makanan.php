<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Makanan extends CI_Controller {

   public function __construct(){
     parent::__construct();
     $this->load->model('Mmakanan');

   }
  public function get_all_data()
  {
    $data = $this->Mmakanan->get_all();
    echo json_encode($data);
  }

  public function get_by_type()
  {
    $type=$this->input->get('p');
    $data = $this->Mmakanan->get_by_id($type);
    echo json_encode($data);
  }
}
