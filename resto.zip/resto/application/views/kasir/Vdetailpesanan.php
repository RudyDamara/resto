<div class="cart-table-area section-padding-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="cart-title mt-50">
                    <h2>Detail Pesanan Minuman </h2>
                </div>

                <div class="cart-table clearfix">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($minuman as $data_minuman) { ?>
                            <tr>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_minuman->nama;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_minuman->harga;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><input type="number" nama="jumlah"></h5>
                              </td>
                            </tr>
                          <?php } ?>
                          </tbody>
                    </table>
                </div>

                <div class="cart-title mt-50">
                    <h2>Detail Pesanan Makanan</h2>
                </div>

                <div class="cart-table clearfix">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($makanan as $data_makanan) { ?>
                            <tr>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_makanan->nama;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_makanan->harga;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><input type="number" nama="jumlah"></h5>
                              </td>
                            </tr>
                          <?php } ?>
                          </tbody>
                    </table>
                </div>

            </div>
          </div>
    </div>
</div>
</div>
<!-- ##### Main Content Wrapper End ##### --> 