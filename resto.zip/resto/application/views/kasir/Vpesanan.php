<div class="cart-table-area section-padding-100">
    <div class="container-fluid">

    <!-- Update data-->
    <?php if (isset($update)) { ?>
    <div class="row">
            <div class="col-12 col-lg-12">
            <div class="box">
            <!-- header -->
            <div class="box-header with-border">
                <h3 class="box-title">Update Pesanan</h3>
                <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                </div>
            </div>
            <!-- body -->
            <div class="box-body">
                <form class="" action="<?php echo base_url('kasir/Pesanan/update_action')?>" method="post">
                    <div class="form-group">
                        <label for="">Nomor Pesanan</label><tr>
                        <input type="text" class="form-control" name="nomor_pemesanan" id="nomor_pemesanan" value="<?php
                        echo "$data_update->nomor_pesanan";?>" readonly="">
                    </div>
                    <div class="form-group">
                        <label for="">Atas nama</label><br>
                        <input type="text" class="form-control" value="<?php
                        echo "$data_update->nama";?>" name="atasnama">
                    </div>
                    <div class="form-group">
                        <label for="">Meja</label><br>
                        <select name="meja" id="meja" value="<?php
                        echo "$data_update->meja";?>">
                            <?php foreach ($meja as $data_meja) {?>
                            <option value="<?php echo $data_meja->id; ?>"><?php echo $data_meja->nama; ?></option>
                            <?php } ?>
                        </select><br><br>
                    </div>
                    <div class="form-group">
                        <label for="">Status</label><br>
                        <select name="status" id="status">
                            <option value="AKTIF">AKTIF</option>
                            <option value="TIDAK AKTIF">TIDAK AKTIF</option>
                        </select><br><br>
                    </div>
                    <div class="form-group"><br><br>
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
                </div>
            </div>
            </div>

        </div>
    </div>
    <?php } ?>
    <!-- end Update data-->

    <!-- Insert data-->
    <?php if (isset($_POST['tambah'])) { ?>
    <div class="row">
            <div class="col-12 col-lg-12">
            <div class="box">
            <!-- header -->
            <div class="box-header with-border">
                <h3 class="box-title">Insert Pesanan</h3>
                <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                </div>
            </div>
            <!-- body -->
            <div class="box-body">
                <form class="" action="<?php echo base_url('kasir/pesanan/insert_action')?>" method="post">
                    <div class="form-group">
                        <label for="">Meja</label><br>
                        <select name="meja" id="meja">
                            <?php foreach ($meja as $data_meja) {?>
                            <option value="<?php echo $data_meja->id; ?>"><?php echo $data_meja->nama; ?></option>
                            <?php } ?>
                        </select><br><br>
                    </div>
                    <div class="form-group">
                        <label for="">Atas nama</label><br>
                        <input type="text" class="form-control" name="atasnama">
                    </div>
                    <div class="form-group"><br><br>
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
                </div>
            </div>
            </div>

        </div>
    </div>
    <?php } ?>
    <!-- end Insert data-->

        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="cart-title mt-50">
                    <h2>Pesanan</h2>
                </div>
                <!-- pemanggilan form Insert data-->
                <form action="" method="post">
                  <button type="submit" name="tambah" class="btn btn-primary">
                  <i class="fa fa-user-plus"></i> Tambah
                  </button>
                </form>
                <!-- selesai pemaanggilan form Insert data-->

                <div class="cart-table clearfix">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th>Nomor Pesanan</th>
                                <th>Meja</th>
                                <th>Nama</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($pesanan as $data_pesanan) { ?>
                            <tr>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_pesanan->nomor_pesanan;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_pesanan->meja;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_pesanan->nama;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_pesanan->status;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                <a href="<?php echo base_url("kasir/pesanan/update/".$data_pesanan->nomor_pesanan);?>" class="btn btn-warning">Update</a>
                                <a href="<?php echo base_url("pelayan/pesanan/detail_pesanan/".$data_pesanan->nomor_pesanan);?>" class="btn btn-success">Detail</a>
                              </td>
                            </tr>
                          <?php } ?>
                          </tbody>
                    </table>
                </div>
            </div>
          </div>
    </div>
</div>
</div>
<!-- ##### Main Content Wrapper End ##### --> 