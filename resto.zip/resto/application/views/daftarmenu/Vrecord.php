<div class="cart-table-area section-padding-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="cart-title mt-50">
                    <h2>Record</h2>
                </div>
                
                <!-- pemanggilan cetak data-->
                <?php if ($this->session->userdata('level') =='pelayan') {?>
                    <a class="btn btn-primary" href="<?php echo base_url('pelayan/record/print')?>">Print</a>
                <?php  } else {?>
                    <a class="btn btn-primary" href="<?php echo base_url('kasir/record/print')?>">Print</a>
                <?php } ?>
                <!-- selesai peanggilan cetak data-->

                <div class="cart-table clearfix">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $no = 1; foreach ($record as $data_record) { ?>
                            <tr>
                              <td class="cart_product_desc">
                                  <h5><?php echo $no++;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_record->keterangan;?></h5>
                              </td>
                            </tr>
                          <?php } ?>
                          </tbody>
                    </table>
                </div>
            </div>
          </div>
    </div>
</div>
</div>
<!-- ##### Main Content Wrapper End ##### --> 