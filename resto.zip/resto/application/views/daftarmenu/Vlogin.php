<div class="cart-table-area section-padding-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="checkout_details_area mt-50 clearfix">

                    <div class="cart-title">
                        <h2>Login</h2>
                    </div>

                    <form id="loginform" action="" method="post">
                        <div class="row">
                          <div class="col-12 mb-3">
                                <input type="text" class="form-control" name="username" id="username" placeholder="Username" value="">
                            </div>
                            <div class="col-12 mb-3">
                                <input type="password" class="form-control" name="password" id="password" placeholder="Password" value="">
                            </div>
                            <div class="col-12 mb-3">
                              <a onclick="login();" class="btn btn-success" id="button_login" name="button_login">Login</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
</div>
<!-- ##### Main Content Wrapper End ##### -->
<script>
function login(){
    var username = $('#username').val();
    var password = $('#password').val();
    
    if (username == '' || password == '') {
      alert('Form masih ada yang kosong');
    } else {
      $('#button_login').attr('disabled', true);
      $.ajax({
        url: '<?php echo base_url("auth/login_user") ?>',
        type: "POST",
        data: $('#loginform').serialize(),
        dataType: "JSON",
        async: false,
        success: function (arr) {
            console.log(arr);
          if (arr.level == 'pelayan') {
            alert('silahkan dilanjutakn halaman selanjutnya');
            location.href = "<?php echo base_url('pelayan/pesanan') ?>";
          }  else if (arr.level == 'kasir') {
            console.log(arr);
            alert('silahkan dilanjutakn ke halaman kasir selanjutnya');
            location.href = "<?php echo base_url('kasir/pesanan') ?>";
          } else {
            console.log(arr);
            alert('username / password salah');
            location.href = "<?php echo base_url('') ?>";
          }
        },

      });
    }
}
</script>