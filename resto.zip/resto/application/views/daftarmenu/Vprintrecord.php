<div class="cart-table-area section-padding-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-8 col-lg-8 col-md-8">
                <div class="cart-title mt-50">
                    <h2>Record <?php echo $this->session->userdata('username'); ?></h2>
                </div>
                <div class="cart-table clearfix">
                    <table border ="1" class="table table-responsive">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $no = 1; foreach ($record as $data_record) { ?>
                            <tr>
                              <td class="cart_product_desc">
                                  <h5><?php echo $no++;?></h5>
                              </td>
                              <td class="cart_product_desc">
                                  <h5><?php echo $data_record->keterangan;?></h5>
                              </td>
                            </tr>
                          <?php } ?>
                          </tbody>
                    </table>
                </div>
            </div>
          </div>
    </div>
</div>
</div>
<script type="text/javascript">
 window.print();
</script>