<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>INI Resto - Makanan</title>

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/core-style.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css')?>">

</head>

<body>
    <!-- Search Wrapper Area Start -->
    <div class="search-wrapper section-padding-100">
        <div class="search-close">
            <i class="fa fa-close" aria-hidden="true"></i>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="search-content">
                        <form action="#" method="get">
                            <input type="search" name="search" id="search" placeholder="Type your keyword...">
                            <button type="submit"><img src="<?php echo base_url("assets/img/core-img/search.png") ?>" alt=""></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Search Wrapper Area End -->

    <!-- ##### Main Content Wrapper Start ##### -->
    <div class="main-content-wrapper d-flex clearfix">

        <!-- Mobile Nav (max width 767px)-->
        <div class="mobile-nav">
            <!-- Navbar Brand -->
            <div class="amado-navbar-brand">
                <!-- Logo Brand -->
                <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url("assets/img/core-img/logo.png")?> "alt=""></a>
            </div>
            <!-- Navbar Toggler -->
            <div class="amado-navbar-toggler">
                <span></span><span></span><span></span>
            </div>
        </div>
        <!-- end Mobile Nav (max width 767px)-->

        <!-- Header Area Start -->
        <header class="header-area clearfix">
            <!-- Close Icon -->
            <div class="nav-close">
                <i class="fa fa-close" aria-hidden="true"></i>
            </div>
            <!-- Logo -->
            <div class="logo">
                <a href="#">
                    <u><h3>INI Resto</h3></u>
                </a>
            </div>
            <u>
                <h5><?php echo $this->session->userdata('level');?></h5>
            </u>
            <!-- Amado Nav -->
            <nav class="amado-nav">
                <ul>
                  <!-- Link Menu -->
                    <?php if ($this->session->userdata('level') == 'pelayan') { ?>
                    <li class="active"><a href="#">Home</a></li>
                    <li><a href="<?php echo base_url("pelayan/Pesanan"); ?>">Pesanan</a></li>
                    <li><a href="<?php echo base_url("pelayan/Makanan"); ?>">Makanan</a></li>
                    <li><a href="<?php echo base_url("pelayan/Minuman"); ?>">Minuman</a></li>
                    <li><a href="<?php echo base_url("pelayan/record"); ?>">Record</a></li>
                    <?php }else{?>
                    <li class="active"><a href="#>">Home</a></li>
                    <li><a href="<?php echo base_url("kasir/Pesanan"); ?>">Pesanan</a></li>
                    <li><a href="<?php echo base_url("kasir/record"); ?>">Record</a></li>
                    <?php }?>
                </ul>
            </nav>
            <!-- Button Group -->
            <div class="amado-btn-group mt-30 mb-100">
                <?php if ($this->session->userdata('username') == null) { ?>
                
                <a href="<?php echo base_url("auth/login"); ?>" class="btn amado-btn mb-15">LOGIN</a>
                <a href="#" class="btn amado-btn active">DAFTAR</a>
                
                <?php }else{?>
                
                <a href="<?php echo base_url("auth/log_out"); ?>" class="btn amado-btn mb-15">LOG OUT</a>
                
                <?php }?>
            </div>

            <!-- Social Button -->
            <div class="social-info d-flex justify-content-between">
                <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
            </div>
        </header>
        <!-- Header Area End --> 
